# ZEC triangular arbitrage scanner (Binance Spot)

This is a **paper-first starter implementation**, not a production-ready live trading system.
It monitors both triangular routes:

- A: USDT -> ZEC -> BTC -> USDT
- B: USDT -> BTC -> ZEC -> USDT

It retrieves depth snapshots over REST, simulates fills across price levels, and estimates fees.
It does **not** submit live orders. The executor's live path is deliberately locked because
three sequential spot orders are not atomic and partial fills can leave inventory exposure.

## Setup (Windows / VS Code or Ubuntu VPS)

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Ubuntu:
source .venv/bin/activate

pip install -r requirements.txt
cp .env.example .env
python main.py
```

On Windows PowerShell, use `Copy-Item .env.example .env` instead of `cp` if needed.

## Initial configuration

Keep:
```
MODE=PAPER
LIVE_TRADING_ENABLED=false
```

`START_CAPITAL_USDT=1000` is a simulation amount. The scanner does not reserve or transfer funds.
`BNB_FEE_DISCOUNT_EXPECTED=0.00075` is only an estimate. Verify the account's actual commission
rate and discount eligibility for each symbol before using it in a production calculation.

## Important implementation limitations

1. The current market-data adapter polls REST depth snapshots. It is intentionally simpler for
   initial validation, but is not a low-latency synchronized WebSocket local order book.
2. The depth simulator assumes fees can be represented as a proportional haircut. Actual Binance
   commissions can be charged in different assets, including BNB; reconcile actual fills and
   commission fields for precise accounting.
3. `Executor` contains IOC pricing and an unwind interface, but live submission is locked.
   A production release must implement:
   - WebSocket diff-depth snapshot/update sequencing and reconnect/resnapshot logic.
   - Signed order submission with idempotent client IDs and timeout reconciliation.
   - Fill-by-fill commission asset accounting and BNB balance checks.
   - Exchange filter handling including MARKET_LOT_SIZE, NOTIONAL, and precision.
   - Partial-fill state machine and verified unwind sizing.
   - User data stream or repeated order-status reconciliation.
   - Daily realized-P&L accounting and a persistent kill switch.
4. Never enable live trading just by changing `.env`. The live path currently refuses to start.

## Why the live path is locked

The three legs cannot be submitted atomically. An order can partially fill, a later order can
reject, and a request timeout can have an unknown execution result. A safe implementation must
query the original client order ID before retrying and must reconcile actual balances and
commission assets before any recovery order. Blindly retrying can duplicate exposure.

## Suggested acceptance tests before live trading

- Verify each route against manually calculated order-book examples.
- Test insufficient depth and stale-book rejection.
- Test tick/step/min-notional rounding.
- Simulate each possible partial-fill point (leg 1, 2, and 3).
- Simulate API timeout after exchange acceptance.
- Simulate BNB insufficient balance and commission charged in quote/base.
- Verify every completed or recovered cycle ends with only USDT exposure (apart from dust).
- Run paper mode continuously and compare predicted versus executable fills.

## API permissions

For future live deployment, use a dedicated API key with Spot Trading only, withdrawals disabled,
and IP allowlisting. Never put API secrets in source code or commit `.env`.
