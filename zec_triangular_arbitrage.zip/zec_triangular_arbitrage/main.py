import asyncio, logging
from decimal import Decimal
from zecarb.config import Config
from zecarb.exchange import BinanceREST
from zecarb.engine import ArbitrageEngine

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

async def main():
    cfg = Config()
    cfg.validate()
    if cfg.mode == "LIVE":
        raise RuntimeError("LIVE execution is deliberately locked. Use MODE=PAPER until live-readiness review is complete.")
    async with BinanceREST(cfg) as ex:
        await ex.load_exchange_info()
        engine = ArbitrageEngine(cfg, ex)
        logging.info("Started %s scanner. Live orders are disabled.", cfg.mode)
        while True:
            try:
                opps = await engine.run_scan()
                if not opps:
                    logging.info("No fully depth-covered opportunity.")
                for o in opps:
                    logging.info("%s | start=%s end=%s profit=%s return=%.4f%%",
                        o.route, o.start_usdt, o.end_usdt, o.net_profit, o.net_return*100)
                    if o.net_profit >= cfg.min_profit and o.net_return >= cfg.min_return:
                        logging.warning("PAPER SIGNAL: %s", o.route)
            except Exception:
                logging.exception("Scan failed")
            await asyncio.sleep(cfg.poll_interval)

if __name__ == "__main__":
    asyncio.run(main())
