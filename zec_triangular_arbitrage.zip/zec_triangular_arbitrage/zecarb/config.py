import os
from dataclasses import dataclass
from decimal import Decimal
from dotenv import load_dotenv

load_dotenv()

def D(name: str, default: str) -> Decimal:
    return Decimal(os.getenv(name, default))

@dataclass(frozen=True)
class Config:
    api_key: str = os.getenv("BINANCE_API_KEY", "")
    api_secret: str = os.getenv("BINANCE_API_SECRET", "")
    base_url: str = os.getenv("BINANCE_BASE_URL", "https://api.binance.com").rstrip("/")
    mode: str = os.getenv("MODE", "PAPER").upper()
    live_enabled: bool = os.getenv("LIVE_TRADING_ENABLED", "false").lower() == "true"
    start_capital: Decimal = D("START_CAPITAL_USDT", "1000")
    max_cycle: Decimal = D("MAX_CYCLE_USDT", "1000")
    min_profit: Decimal = D("MIN_NET_PROFIT_USDT", "3")
    min_return: Decimal = D("MIN_NET_RETURN", "0.003")
    max_slippage: Decimal = D("MAX_SLIPPAGE", "0.001")
    max_book_age: float = float(os.getenv("MAX_BOOK_AGE_SECONDS", "1.5"))
    poll_interval: float = float(os.getenv("POLL_INTERVAL_SECONDS", "0.35"))
    depth_limit: int = int(os.getenv("DEPTH_LIMIT", "100"))
    daily_loss_limit: Decimal = D("DAILY_LOSS_LIMIT_USDT", "10")
    max_failures: int = int(os.getenv("MAX_CONSECUTIVE_FAILURES", "2"))
    expected_bnb_discount: Decimal = D("BNB_FEE_DISCOUNT_EXPECTED", "0.00075")

    @property
    def live(self) -> bool:
        return self.mode == "LIVE" and self.live_enabled

    def validate(self):
        if self.mode not in {"PAPER", "LIVE"}:
            raise ValueError("MODE must be PAPER or LIVE")
        if self.live and (not self.api_key or not self.api_secret):
            raise ValueError("Live mode requires Binance API credentials")
        if self.max_cycle <= 0 or self.max_cycle > self.start_capital:
            raise ValueError("MAX_CYCLE_USDT must be > 0 and <= START_CAPITAL_USDT")
        if self.min_return <= 0 or self.max_slippage <= 0:
            raise ValueError("Profit and slippage thresholds must be positive")
