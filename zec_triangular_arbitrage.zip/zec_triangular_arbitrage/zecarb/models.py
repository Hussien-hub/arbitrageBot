from dataclasses import dataclass
from decimal import Decimal
from time import time

@dataclass
class Book:
    symbol: str
    bids: list[tuple[Decimal, Decimal]]
    asks: list[tuple[Decimal, Decimal]]
    updated_at: float

    def fresh(self, max_age: float) -> bool:
        return time() - self.updated_at <= max_age

@dataclass
class Simulation:
    input_amount: Decimal
    output_amount: Decimal
    average_price: Decimal
    worst_price: Decimal
    complete: bool
    levels_used: int

@dataclass
class Opportunity:
    route: str
    start_usdt: Decimal
    end_usdt: Decimal
    net_profit: Decimal
    net_return: Decimal
    legs: list[dict]
