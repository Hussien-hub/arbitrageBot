import asyncio, logging, uuid
from decimal import Decimal, ROUND_DOWN
from time import time
from .models import Simulation, Opportunity

log = logging.getLogger("zecarb")

def floor_step(value: Decimal, step: Decimal) -> Decimal:
    return (value / step).to_integral_value(rounding=ROUND_DOWN) * step

def spend_quote(book, quote_amount, fee_rate):
    """Buy base using quote; walks asks. Fee conservatively deducted from received base."""
    remaining, base, quote_spent, worst, levels = quote_amount, Decimal(0), Decimal(0), Decimal(0), 0
    for price, qty in book.asks:
        cost = price * qty
        take_quote = min(remaining, cost)
        if take_quote <= 0: break
        got = take_quote / price
        base += got
        quote_spent += take_quote
        remaining -= take_quote
        worst, levels = price, levels + 1
        if remaining <= Decimal("1e-18"): break
    complete = remaining <= max(Decimal("1e-8"), quote_amount * Decimal("0.000001"))
    base *= (Decimal(1) - fee_rate)
    avg = quote_spent / (base / (Decimal(1)-fee_rate)) if base else Decimal(0)
    return Simulation(quote_amount-remaining, base, avg, worst, complete, levels)

def sell_base(book, base_amount, fee_rate):
    """Sell base into bids; fee conservatively deducted from quote proceeds."""
    remaining, quote, base_sold, worst, levels = base_amount, Decimal(0), Decimal(0), Decimal(0), 0
    for price, qty in book.bids:
        take = min(remaining, qty)
        if take <= 0: break
        quote += take * price
        base_sold += take
        remaining -= take
        worst, levels = price, levels + 1
        if remaining <= Decimal("1e-18"): break
    complete = remaining <= max(Decimal("1e-10"), base_amount * Decimal("0.000001"))
    quote *= (Decimal(1) - fee_rate)
    return Simulation(base_sold, quote, quote/base_sold if base_sold else Decimal(0),
                      worst, complete, levels)

class ArbitrageEngine:
    def __init__(self, cfg, exchange):
        self.cfg, self.ex = cfg, exchange
        self.fees = {s: cfg.expected_bnb_discount for s in ("ZECUSDT","ZECBTC","BTCUSDT")}
        self.last_books = {}

    async def refresh(self):
        symbols = ("ZECUSDT","ZECBTC","BTCUSDT")
        books = await asyncio.gather(*(self.ex.depth(s, self.cfg.depth_limit) for s in symbols))
        self.last_books = {b.symbol:b for b in books}
        return self.last_books

    def evaluate(self, books, capital):
        if any(not b.fresh(self.cfg.max_book_age) for b in books.values()):
            return []
        a, b, c = books["ZECUSDT"], books["ZECBTC"], books["BTCUSDT"]
        fee = self.cfg.expected_bnb_discount
        opportunities = []

        # Route A: USDT -> ZEC (ask) -> BTC (bid) -> USDT (bid)
        x = spend_quote(a, capital, fee)
        y = sell_base(b, x.output_amount, fee) if x.complete else None
        z = sell_base(c, y.output_amount, fee) if y and y.complete else None
        if x.complete and y and y.complete and z and z.complete:
            out = z.output_amount
            opportunities.append(Opportunity("A: USDT>ZEC>BTC>USDT", capital, out,
                out-capital, (out-capital)/capital, [
                    {"symbol":"ZECUSDT","side":"BUY","input":capital,"output":x.output_amount},
                    {"symbol":"ZECBTC","side":"SELL","input":x.output_amount,"output":y.output_amount},
                    {"symbol":"BTCUSDT","side":"SELL","input":y.output_amount,"output":out}]))

        # Route B: USDT -> BTC (ask) -> ZEC (ask in BTC) -> USDT (bid)
        x = spend_quote(c, capital, fee)
        y = spend_quote(b, x.output_amount, fee) if x.complete else None
        z = sell_base(a, y.output_amount, fee) if y and y.complete else None
        if x.complete and y and y.complete and z and z.complete:
            out = z.output_amount
            opportunities.append(Opportunity("B: USDT>BTC>ZEC>USDT", capital, out,
                out-capital, (out-capital)/capital, [
                    {"symbol":"BTCUSDT","side":"BUY","input":capital,"output":x.output_amount},
                    {"symbol":"ZECBTC","side":"BUY","input":x.output_amount,"output":y.output_amount},
                    {"symbol":"ZECUSDT","side":"SELL","input":y.output_amount,"output":out}]))
        return sorted(opportunities, key=lambda o:o.net_profit, reverse=True)

    async def run_scan(self):
        books = await self.refresh()
        capital = min(self.cfg.start_capital, self.cfg.max_cycle)
        return self.evaluate(books, capital)

class Executor:
    """Sequential IOC executor. Any incomplete leg triggers a direct unwind to USDT."""
    def __init__(self, cfg, exchange):
        self.cfg, self.ex = cfg, exchange

    async def execute_leg(self, symbol, side, qty, book):
        f = self.ex.filters[symbol]
        qty = floor_step(qty, f["step"])
        if qty < f["min_qty"]:
            raise RuntimeError(f"{symbol} quantity below minQty")
        # Marketable IOC limit with a bounded price collar.
        if side == "BUY":
            best = book.asks[0][0]
            price = best * (Decimal(1) + self.cfg.max_slippage)
            price = (price / f["tick"]).to_integral_value(rounding=ROUND_DOWN) * f["tick"]
        else:
            best = book.bids[0][0]
            price = best * (Decimal(1) - self.cfg.max_slippage)
            price = (price / f["tick"]).to_integral_value(rounding=ROUND_DOWN) * f["tick"]
        cid = "arb" + uuid.uuid4().hex[:20]
        result = await self.ex.place_ioc(symbol, side, qty, price, cid)
        executed = Decimal(result.get("executedQty", "0"))
        quote = Decimal(result.get("cummulativeQuoteQty", "0"))
        if result.get("status") not in {"FILLED","EXPIRED"}:
            # Query once to resolve any non-terminal/ambiguous state.
            result = await self.ex.query_order(symbol, result["orderId"])
            executed = Decimal(result.get("executedQty", "0"))
            quote = Decimal(result.get("cummulativeQuoteQty", "0"))
        return {"result":result, "executed":executed, "quote":quote}

    async def unwind(self, asset, qty, books):
        """Sell residual ZEC or BTC directly to USDT. Uses fresh depth and conservative IOC."""
        symbol = asset + "USDT"
        if symbol not in books or qty <= 0:
            raise RuntimeError(f"Cannot safely unwind {asset}; manual intervention required")
        return await self.execute_leg(symbol, "SELL", qty, books[symbol])

    async def execute(self, opportunity, books):
        if not self.cfg.live:
            log.warning("PAPER mode: opportunity logged, no orders sent.")
            return {"mode":"PAPER","route":opportunity.route,
                    "expected_profit":str(opportunity.net_profit)}
        # The live path intentionally refuses automatic execution until balances,
        # exact commission assets, and all leg quantities are reconciled by operator.
        # This prevents unsafe assumptions about BNB commissions and partial fills.
        raise RuntimeError("Live order path is locked in this starter release. Complete the live-readiness checklist first.")
