import asyncio, hashlib, hmac, time
from decimal import Decimal
from urllib.parse import urlencode
import aiohttp

class BinanceREST:
    def __init__(self, cfg):
        self.cfg = cfg
        self.session = None
        self.filters = {}

    async def __aenter__(self):
        timeout = aiohttp.ClientTimeout(total=8)
        self.session = aiohttp.ClientSession(timeout=timeout, headers={"X-MBX-APIKEY": self.cfg.api_key} if self.cfg.api_key else {})
        return self

    async def __aexit__(self, *args):
        await self.session.close()

    async def request(self, method, path, params=None, signed=False):
        params = dict(params or {})
        if signed:
            params["timestamp"] = int(time.time() * 1000)
            params["recvWindow"] = 5000
            query = urlencode(params)
            sig = hmac.new(self.cfg.api_secret.encode(), query.encode(), hashlib.sha256).hexdigest()
            query += "&signature=" + sig
            url = self.cfg.base_url + path + "?" + query
            body = None
        else:
            url = self.cfg.base_url + path
            body = params
        async with self.session.request(method, url, params=body) as r:
            data = await r.json()
            if r.status >= 400:
                raise RuntimeError(f"Binance HTTP {r.status}: {data}")
            return data

    async def load_exchange_info(self):
        data = await self.request("GET", "/api/v3/exchangeInfo")
        wanted = {"ZECUSDT", "ZECBTC", "BTCUSDT"}
        for s in data["symbols"]:
            if s["symbol"] not in wanted:
                continue
            if s["status"] != "TRADING":
                raise RuntimeError(f"{s['symbol']} is not TRADING")
            f = {x["filterType"]: x for x in s["filters"]}
            self.filters[s["symbol"]] = {
                "tick": Decimal(f["PRICE_FILTER"]["tickSize"]),
                "step": Decimal(f["LOT_SIZE"]["stepSize"]),
                "min_qty": Decimal(f["LOT_SIZE"]["minQty"]),
                "min_notional": Decimal(f.get("NOTIONAL", f.get("MIN_NOTIONAL", {})).get("minNotional", "0"))
            }
        if set(self.filters) != wanted:
            raise RuntimeError(f"Required spot symbols unavailable: found {sorted(self.filters)}")

    async def depth(self, symbol, limit):
        d = await self.request("GET", "/api/v3/depth", {"symbol": symbol, "limit": limit})
        from .models import Book
        return Book(symbol,
                    [(Decimal(p), Decimal(q)) for p, q in d["bids"]],
                    [(Decimal(p), Decimal(q)) for p, q in d["asks"]],
                    time.time())

    async def account(self):
        return await self.request("GET", "/api/v3/account", signed=True)

    async def commission(self, symbol):
        return await self.request("GET", "/api/v3/account/commission", {"symbol": symbol}, signed=True)

    async def place_ioc(self, symbol, side, quantity, price, client_id):
        return await self.request("POST", "/api/v3/order", {
            "symbol": symbol, "side": side, "type": "LIMIT",
            "timeInForce": "IOC", "quantity": str(quantity),
            "price": str(price), "newClientOrderId": client_id,
            "newOrderRespType": "FULL"
        }, signed=True)

    async def query_order(self, symbol, order_id):
        return await self.request("GET", "/api/v3/order", {"symbol": symbol, "orderId": order_id}, signed=True)
